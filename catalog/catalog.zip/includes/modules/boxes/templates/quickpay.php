<div class="panel panel-default">
  <div class="panel-heading"><?php echo MODULE_BOXES_QUICKPAY_BOX_TITLE; ?></div>
  <div class="panel-body text-center"><?php echo $output; ?></div>
</div>
